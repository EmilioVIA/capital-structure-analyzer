# Capital Structure Analyzer

Aplicación web de análisis de estructura de capital y WACC construida con React, TypeScript, Vite, Tailwind CSS y Recharts.

## Requisitos
- Node.js 20 o superior
- npm

## Instalación y ejecución
```bash
npm install
npm run dev
```
Abre la URL local que indique Vite (normalmente http://localhost:5173).

## Compilar y probar
```bash
npm run build
npm test
```

## Funcionalidades
- Calculadora de WACC y costo de deuda después de impuestos.
- Costo de capital propio directo o por CAPM.
- Validación de la estructura de financiamiento.
- Cinco escenarios iniciales y escenarios personalizados.
- Costos Kd y Ke editables por escenario para reflejar riesgo financiero.
- Dashboard con KPIs, composición de capital, barras y curva WACC/deuda.
- Interpretaciones automáticas y advertencias por concentración de deuda.
- Guardado local en el navegador, exportación a PDF y Excel.
- Selección de moneda y escala de unidades.

## Notas metodológicas
- Tasas expresadas como porcentajes en la interfaz y convertidas a decimales en el motor financiero.
- WACC utiliza ponderaciones de deuda y capital sobre V = D + E.
- Se supone aprovechamiento total del escudo fiscal; modifica la tasa fiscal si este supuesto no aplica.
- Los costos por escenario son supuestos del usuario; no se estiman automáticamente con una curva de riesgo.
- El menor WACC no equivale necesariamente a una estructura óptima: deben evaluarse solvencia, liquidez, cobertura, covenants y costos de insolvencia.
- Los resultados son una herramienta de análisis y no constituyen asesoría financiera.

## Estructura
- `src/finance.ts`: funciones financieras puras y validaciones.
- `src/App.tsx`: interfaz, estado, escenarios, visualizaciones y exportaciones.
- `src/__tests__/finance.test.ts`: pruebas unitarias de fórmulas y validaciones.
